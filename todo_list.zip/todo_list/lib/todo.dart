class Todo {
  final int id;
  final String title;
  final String desc;
  final bool completed;
  Todo(
      {required this.id,
      required this.title,
      required this.desc,
      required this.completed});

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'id': id,
      'title': title,
      'description': desc,
      'completed': completed,
    };
  }

// Uh why do we need factory here?? Asking for a friend.
  factory Todo.fromMap(Map<String, dynamic> map) {
    return Todo(
      id: map['id'] as int,
      title: map['title'] as String,
      desc: map['description'] as String,
      completed: map['completed'] == 0 ? false : true,
    );
  }
}
